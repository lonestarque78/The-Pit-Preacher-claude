export const metadata = {
  title: 'Your Pitmaster Dashboard',
  description: 'Track your active cooks, review your cook history, and manage your BBQ cook log. Your personal pitmaster dashboard from The Pit Preacher.'
}

import { createServerClient } from "@/lib/supabase-server";
import { getTier } from "@/lib/premium";
import { getRandomVerse } from "@/lib/verses";
import Link from "next/link";
import CookList from "./CookList";

function tierBadgeStyle(tier: string): { bg: string; border: string; label: string } {
  if (tier === "basic")     return { bg: "rgba(201,151,58,0.1)", border: "1px solid rgba(201,151,58,0.3)", label: "Basic" };
  if (tier === "backyard")  return { bg: "rgba(139,105,26,0.2)", border: "1px solid rgba(201,151,58,0.3)", label: "Backyard" };
  if (tier === "pitmaster") return { bg: "rgba(201,151,58,0.2)", border: "1px solid #C9973A",              label: "✦ Pitmaster" };
  return { bg: "rgba(201,151,58,0.1)", border: "1px solid rgba(201,151,58,0.3)", label: "Free Plan" };
}

export default async function DashboardPage() {
  const supabase = await createServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  const verse = getRandomVerse();

  const heroSection = (
    <>
      <div style={{
        background: "radial-gradient(ellipse at 50% 110%, rgba(232,98,10,0.15) 0%, transparent 55%), linear-gradient(180deg, #0c0a08 0%, #1a1008 40%, #0c0a08 100%)",
        padding: "1.5rem 2rem 1rem",
        textAlign: "center",
      }}>
        <p style={{ fontFamily: "var(--font-ui)", color: "#C9973A", textTransform: "uppercase", letterSpacing: "0.2em", fontSize: "0.75rem", marginTop: 0, marginBottom: "var(--space-3)" }}>
          ✦ Lone Star Que ✦
        </p>
        <p style={{ fontFamily: "var(--font-heading)", fontStyle: "italic", color: "#C9973A", fontSize: "clamp(1rem, 2.5vw, 1.4rem)", fontWeight: 400, marginTop: 0, marginBottom: "var(--space-2)" }}>
          The Gospel of Great BBQ
        </p>
        <h1 style={{ margin: 0, lineHeight: 1.05 }}>
          <span style={{ display: "block", fontFamily: "var(--font-heading)", color: "#F5E6C8", fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 400 }}>The</span>
          <span style={{ display: "inline", fontFamily: "var(--font-heading)", color: "#F5E6C8", fontSize: "clamp(3rem, 8vw, 7rem)", fontWeight: 900 }}>Pit</span>
          {" "}
          <span style={{ display: "inline", fontFamily: "var(--font-heading)", color: "transparent", WebkitTextStroke: "2px #C9973A", fontSize: "clamp(3rem, 8vw, 7rem)", fontWeight: 900, fontStyle: "italic" }}>Preacher</span>
        </h1>
      </div>
      <div style={{ height: "1px", background: "rgba(201,151,58,0.2)" }} />
      <p style={{ fontFamily: "var(--font-body)", fontStyle: "italic", color: "var(--color-text-muted)", fontSize: "0.85rem", textAlign: "center", margin: "var(--space-2) auto 0", maxWidth: "520px", lineHeight: 1.6, padding: "0 var(--space-3)" }}>
        &ldquo;{verse.text}&rdquo;
      </p>
    </>
  );

  // ── LOGGED OUT ─────────────────────────────────────────────────────────────

  if (!user) {
    return (
      <div>
        {heroSection}

        <div style={{ textAlign: "center", padding: "var(--space-5) var(--space-4)" }}>
          <h2 style={{ fontFamily: "var(--font-heading)", fontSize: "clamp(1.8rem, 4vw, 2.5rem)", color: "#F5E6C8", margin: "0 0 var(--space-3)" }}>
            Welcome to the Pulpit
          </h2>
          <p style={{ fontFamily: "var(--font-body)", color: "var(--color-text-muted)", maxWidth: "520px", margin: "0 auto var(--space-4)" }}>
            The Pit Preacher is your personal BBQ coach. Built by a pitmaster, powered by 25 years of fire and smoke.
          </p>
          <div style={{ display: "flex", gap: "var(--space-3)", justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/auth/login?tab=signup" style={{ display: "inline-block", background: "#C9973A", color: "var(--color-bg)", fontFamily: "var(--font-ui)", padding: "12px 28px", borderRadius: "var(--radius-lg)", textDecoration: "none" }}>
              Join Free →
            </Link>
            <Link href="/premium" style={{ display: "inline-block", background: "transparent", border: "1px solid rgba(201,151,58,0.4)", color: "#C9973A", fontFamily: "var(--font-ui)", padding: "12px 28px", borderRadius: "var(--radius-lg)", textDecoration: "none" }}>
              See Plans
            </Link>
          </div>
        </div>

        <div style={{ maxWidth: "1000px", margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "var(--space-4)", padding: "var(--space-2) var(--space-4) var(--space-5)" }}>
          {[
            { heading: "The Preacher",      body: "Your personal pitmaster available at 3am when your brisket is stalling. Ask anything. Get real answers from someone who has cooked it.",                                         tag: "Available on all plans" },
            { heading: "Live Cook Mode",    body: "Real-time coaching from the moment the fire starts to the moment you slice. The Preacher watches your cook and tells you exactly what to do next.",                             tag: "Available on all plans" },
            { heading: "Your Cook History", body: "Every cook logged. Every lesson saved. Every temp recorded. Build a personal library of your best cooks and what made them great.",                                             tag: "Basic plan and above"   },
          ].map(card => (
            <div key={card.heading} style={{ background: "var(--color-bg-alt)", borderTop: "2px solid #C9973A", borderRadius: "var(--radius-lg)", padding: "var(--space-4)", display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
              <h3 style={{ fontFamily: "var(--font-heading)", fontSize: "1.2rem", color: "#F5E6C8", margin: 0 }}>{card.heading}</h3>
              <p style={{ fontFamily: "var(--font-body)", color: "var(--color-text-muted)", fontSize: "0.9rem", lineHeight: 1.6, margin: 0, flex: 1 }}>{card.body}</p>
              <p style={{ fontFamily: "var(--font-ui)", fontSize: "0.7rem", color: "#C9973A", textTransform: "uppercase", letterSpacing: "0.1em", margin: 0 }}>{card.tag}</p>
            </div>
          ))}
        </div>

      </div>
    );
  }

  // ── LOGGED IN — data ───────────────────────────────────────────────────────

  const [profileRes, tier, allCooksRes] = await Promise.all([
    supabase.from("profiles").select("display_name, profile_complete").eq("id", user.id).single(),
    getTier(user.id, supabase),
    supabase.from("cooks").select("*").eq("user_id", user.id).order("created_at", { ascending: false }),
  ]);

  const profile     = profileRes.data;
  const allCooks    = (allCooksRes.data ?? []) as any[];
  const displayName = profile?.display_name || "Pitmaster";
  const badge       = tierBadgeStyle(tier);

  // Load cook_logs for all cook IDs
  const cookIds = allCooks.map(c => c.id as string);
  let cookLogMap: Record<string, any> = {};
  if (cookIds.length > 0) {
    const { data: logsData } = await supabase.from("cook_logs").select("*").in("cook_id", cookIds);
    for (const log of logsData ?? []) cookLogMap[log.cook_id] = log;
  }

  // Abandoned cook check
  const renderNow = new Date();
  const fortyEightHoursAgo = new Date(renderNow.getTime() - 48 * 60 * 60 * 1000).toISOString();
  const finalCooks: any[] = [];
  for (const cook of allCooks) {
    if (cook.status === "in_progress") {
      const cookAgeMs = renderNow.getTime() - new Date(cook.created_at).getTime();
      if (cookAgeMs > 48 * 60 * 60 * 1000) {
        const { count } = await supabase
          .from("cook_events")
          .select("*", { count: "exact", head: true })
          .eq("cook_id", cook.id)
          .gte("created_at", fortyEightHoursAgo);
        if ((count ?? 0) === 0) {
          await supabase.from("cooks").update({ status: "abandoned" }).eq("id", cook.id);
          finalCooks.push({ ...cook, status: "abandoned" });
          continue;
        }
      }
    }
    finalCooks.push(cook);
  }

  // ── LOGGED IN — render ─────────────────────────────────────────────────────

  return (
    <div>

      {/* Compact header bar */}
      <div style={{ background: "var(--color-bg-alt)", borderBottom: "1px solid rgba(201,151,58,0.15)", padding: "var(--space-2) var(--space-4)", minHeight: "72px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-4)", flexWrap: "wrap" }}>
        <div>
          <p style={{ fontFamily: "var(--font-ui)", color: "#C9973A", textTransform: "uppercase", letterSpacing: "0.2em", fontSize: "0.65rem", margin: "0 0 2px" }}>✦ The Pit Preacher ✦</p>
          <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "1.3rem", color: "#F5E6C8", margin: 0, fontWeight: 400 }}>The Pit Preacher</h1>
        </div>
        <div style={{ textAlign: "right", maxWidth: "280px" }}>
          <p style={{ fontFamily: "var(--font-body)", fontStyle: "italic", color: "var(--color-text-muted)", fontSize: "0.75rem", margin: "0 0 2px", lineHeight: 1.4 }}>
            &ldquo;{verse.text.length > 80 ? verse.text.slice(0, 80) + "…" : verse.text}&rdquo;
          </p>
          <p style={{ fontFamily: "var(--font-ui)", fontSize: "0.6rem", color: "#C9973A", textTransform: "uppercase", letterSpacing: "0.15em", margin: 0 }}>{verse.chapter}</p>
        </div>
      </div>

      {/* Welcome row */}
      <div style={{ padding: "var(--space-2) var(--space-4)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-3)", borderBottom: "1px solid rgba(201,151,58,0.08)" }}>
        <p style={{ fontFamily: "var(--font-heading)", fontSize: "1.1rem", color: "#F5E6C8", margin: 0 }}>Welcome back, {displayName}</p>
        <span style={{ fontFamily: "var(--font-ui)", fontSize: "0.7rem", padding: "4px 14px", borderRadius: "100px", background: badge.bg, color: "#C9973A", border: badge.border, textTransform: "uppercase", letterSpacing: "0.08em", whiteSpace: "nowrap" }}>
          {badge.label}
        </span>
      </div>

      {/* Cook list (client component — filter cards + cook cards) */}
      <CookList cooks={finalCooks} logsMap={cookLogMap} />

      {/* Tier-aware marketing */}
      {tier !== "pitmaster" && (
        <>
          <div style={{ margin: "0 var(--space-4) var(--space-3)", display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
            <div style={{ flex: 1, height: "1px", background: "rgba(201,151,58,0.15)" }} />
            <p style={{ fontFamily: "var(--font-ui)", fontSize: "0.65rem", color: "#C9973A", textTransform: "uppercase", letterSpacing: "0.2em", margin: 0, whiteSpace: "nowrap" }}>✦ Level Up Your Cook ✦</p>
            <div style={{ flex: 1, height: "1px", background: "rgba(201,151,58,0.15)" }} />
          </div>
          <div style={{ padding: "0 var(--space-4) var(--space-4)" }}>

            {tier === "free" && (
              <div style={{ background: "var(--color-bg-alt)", border: "1px solid rgba(201,151,58,0.3)", borderRadius: "var(--radius-lg)", padding: "var(--space-4)" }}>
                <h3 style={{ fontFamily: "var(--font-heading)", fontSize: "1.1rem", color: "#F5E6C8", margin: "0 0 var(--space-2)" }}>Unlock the Full Pit Preacher Experience</h3>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", color: "var(--color-text-muted)", margin: "0 0 var(--space-3)" }}>You&apos;re on the free plan. Here&apos;s what you&apos;re missing:</p>
                <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-1)", marginBottom: "var(--space-4)" }}>
                  {[
                    "Cook Logs & History — track every cook, every lesson, every rating",
                    "Flavor Memory — save the flavor combos that work for you",
                    "Wood Flavor Lab — learn exactly how every wood affects every meat",
                    "Fix My Cook — panic button for mid-cook emergencies",
                  ].map(f => (
                    <p key={f} style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", color: "var(--color-text-muted)", margin: 0 }}>
                      <span style={{ color: "#C9973A" }}>·</span> {f}
                    </p>
                  ))}
                </div>
                <div style={{ display: "flex", gap: "var(--space-3)", flexWrap: "wrap" }}>
                  <Link href="/premium" style={{ display: "inline-block", background: "#C9973A", color: "var(--color-bg)", fontFamily: "var(--font-ui)", fontSize: "0.85rem", padding: "10px 20px", borderRadius: "var(--radius-md)", textDecoration: "none" }}>
                    Upgrade to Basic — $3.99/mo
                  </Link>
                  <Link href="/premium" style={{ display: "inline-block", background: "transparent", border: "1px solid rgba(201,151,58,0.4)", color: "#C9973A", fontFamily: "var(--font-ui)", fontSize: "0.85rem", padding: "10px 20px", borderRadius: "var(--radius-md)", textDecoration: "none" }}>
                    See All Plans
                  </Link>
                </div>
              </div>
            )}

            {tier === "basic" && (
              <div style={{ background: "var(--color-bg-alt)", border: "1px solid rgba(201,151,58,0.15)", borderRadius: "var(--radius-lg)", padding: "var(--space-4)" }}>
                <h3 style={{ fontFamily: "var(--font-heading)", fontSize: "1rem", color: "#F5E6C8", margin: "0 0 var(--space-2)" }}>Ready for More?</h3>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", color: "var(--color-text-muted)", margin: "0 0 var(--space-3)" }}>
                  Upgrade to Backyard and unlock advanced features including Secret Finishing Moves, Smoke Color Interpreter, and Pit Preacher Challenges.
                </p>
                <Link href="/premium" style={{ display: "inline-block", background: "#C9973A", color: "var(--color-bg)", fontFamily: "var(--font-ui)", fontSize: "0.85rem", padding: "10px 20px", borderRadius: "var(--radius-md)", textDecoration: "none" }}>
                  Upgrade to Backyard — $7.99/mo
                </Link>
              </div>
            )}

            {tier === "backyard" && (
              <div style={{ background: "var(--color-bg-alt)", border: "1px solid rgba(201,151,58,0.1)", borderRadius: "var(--radius-lg)", padding: "var(--space-3) var(--space-4)", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "var(--space-2)" }}>
                <p style={{ fontFamily: "var(--font-body)", fontSize: "0.85rem", color: "var(--color-text-muted)", margin: 0 }}>
                  Ready for the Pitmaster tier? Unlock The Pitmaster&apos;s Table and elite techniques.
                </p>
                <Link href="/premium" style={{ fontFamily: "var(--font-ui)", fontSize: "0.8rem", color: "#C9973A", textDecoration: "none", whiteSpace: "nowrap" }}>
                  Learn more →
                </Link>
              </div>
            )}

          </div>
        </>
      )}

    </div>
  );
}
